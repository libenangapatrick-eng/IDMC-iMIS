$ErrorActionPreference = 'Stop'

$root = 'C:\Users\liben\Documents\IDMC_iMIS\apps\backend'
$pack = Split-Path -Parent $MyInvocation.MyCommand.Path
$backup = Join-Path $root ("backup-api-pack-" + (Get-Date -Format 'yyyyMMdd-HHmmss'))

if (-not (Test-Path $root)) {
    throw "Backend path not found: $root"
}

New-Item -ItemType Directory -Path $backup -Force | Out-Null

$files = @(
    'src\app.ts',
    'src\routes\index.ts',
    'src\modules\finance\routes\finance.routes.ts',
    'src\utils\resourceCrud.ts',
    'src\modules\hr\hr.routes.ts',
    'src\modules\operations\operations.routes.ts',
    'src\modules\hostel\hostel.routes.ts',
    'src\modules\library\library.routes.ts'
)

foreach ($relative in $files) {
    $source = Join-Path $pack $relative
    $target = Join-Path $root $relative

    if (-not (Test-Path $source)) {
        throw "Pack file missing: $relative"
    }

    if (Test-Path $target) {
        $backupTarget = Join-Path $backup $relative
        New-Item -ItemType Directory -Path (Split-Path $backupTarget -Parent) -Force | Out-Null
        Copy-Item $target $backupTarget -Force
    }

    New-Item -ItemType Directory -Path (Split-Path $target -Parent) -Force | Out-Null
    Copy-Item $source $target -Force
}

Write-Host "Backend API pack applied." -ForegroundColor Green
Write-Host "Backup: $backup" -ForegroundColor Yellow

Set-Location $root
npm run typecheck
if ($LASTEXITCODE -ne 0) { throw 'Typecheck failed.' }

npm run build
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
