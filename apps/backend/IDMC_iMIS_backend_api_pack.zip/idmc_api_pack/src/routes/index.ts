import { Router } from "express";

import financeRoutes from "../modules/finance/routes/finance.routes.js";
import academicsRoutes from "../modules/academics/academics.routes.js";
import authRoutes from "../modules/auth/routes/auth.routes.js";
import usersRoutes from "../modules/users/routes/users.routes.js";
import rolesRoutes from "../modules/users/routes/roles.routes.js";
import hrRoutes from "../modules/hr/hr.routes.js";
import operationsRoutes from "../modules/operations/operations.routes.js";
import hostelRoutes from "../modules/hostel/hostel.routes.js";
import libraryRoutes from "../modules/library/library.routes.js";

const router = Router();

router.use("/auth", authRoutes);
router.use("/finance", financeRoutes);
router.use("/academics", academicsRoutes);
router.use("/users", usersRoutes);
router.use("/roles", rolesRoutes);
router.use("/hr", hrRoutes);
router.use("/operations", operationsRoutes);
router.use("/hostel", hostelRoutes);
router.use("/library", libraryRoutes);

export default router;
