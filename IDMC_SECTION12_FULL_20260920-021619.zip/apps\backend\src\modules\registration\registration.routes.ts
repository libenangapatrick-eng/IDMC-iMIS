﻿import { Router } from "express";
import { authenticate } from "../../middleware/auth.js";
import { registerCrudResource } from "../../utils/resourceCrud.js";

const router = Router();

router.use(authenticate);

const VIEW = "registration.view";
const MANAGE = "registration.manage";

registerCrudResource(
  router,
  {
    moduleCode: "REGISTRATION",
    entityType: "student_registrations",
    table: "student_registrations",
    permissionView: VIEW,
    permissionManage: MANAGE,

    searchFields: [
      "registration_number",
      "registration_status",
      "academic_eligibility_status",
      "finance_eligibility_status",
      "document_eligibility_status"
    ],

    filterFields: [
      "student_id",
      "academic_year_id",
      "semester_id",
      "programme_id",
      "programme_version_id",
      "registration_status",
      "academic_eligibility_status",
      "finance_eligibility_status",
      "document_eligibility_status"
    ],

    defaultOrderField: "created_at",

    fields: {
      studentId: "student_id",
      academicYearId: "academic_year_id",
      semesterId: "semester_id",
      programmeId: "programme_id",
      programmeVersionId: "programme_version_id",
      registrationNumber: "registration_number",
      registrationStatus: "registration_status",
      academicEligibilityStatus: "academic_eligibility_status",
      financeEligibilityStatus: "finance_eligibility_status",
      documentEligibilityStatus: "document_eligibility_status",
      totalRegisteredCredits: "total_registered_credits",
      minimumCredits: "minimum_credits",
      maximumCredits: "maximum_credits",
      submittedAt: "submitted_at",
      approvedAt: "approved_at",
      approvedBy: "approved_by",
      lockedAt: "locked_at",
      lockedBy: "locked_by",
      rejectionReason: "rejection_reason",
      notes: "notes",
      createdBy: "created_by",
      updatedBy: "updated_by"
    }
  },
  "/"
);

registerCrudResource(
  router,
  {
    moduleCode: "REGISTRATION",
    entityType: "course_registrations",
    table: "course_registrations",
    permissionView: VIEW,
    permissionManage: MANAGE,

    searchFields: [
      "registration_status"
    ],

    filterFields: [
      "student_registration_id",
      "student_id",
      "course_offering_id",
      "registration_status"
    ],

    defaultOrderField: "created_at",

    fields: {
      studentRegistrationId: "student_registration_id",
      studentId: "student_id",
      courseOfferingId: "course_offering_id",
      registrationStatus: "registration_status",
      createdBy: "created_by",
      updatedBy: "updated_by"
    }
  },
  "/courses"
);

registerCrudResource(
  router,
  {
    moduleCode: "REGISTRATION",
    entityType: "course_add_drop_requests",
    table: "course_add_drop_requests",
    permissionView: VIEW,
    permissionManage: MANAGE,

    searchFields: [
      "request_type",
      "request_status",
      "reason",
      "decision_reason"
    ],

    filterFields: [
      "student_registration_id",
      "course_registration_id",
      "request_type",
      "request_status"
    ],

    defaultOrderField: "created_at",

    fields: {
      studentRegistrationId: "student_registration_id",
      courseRegistrationId: "course_registration_id",
      requestType: "request_type",
      requestStatus: "request_status",
      reason: "reason",
      decisionReason: "decision_reason",
      requestedBy: "requested_by",
      reviewedBy: "reviewed_by",
      reviewedAt: "reviewed_at"
    }
  },
  "/add-drop"
);

registerCrudResource(
  router,
  {
    moduleCode: "REGISTRATION",
    entityType: "registration_approvals",
    table: "registration_approvals",
    permissionView: VIEW,
    permissionManage: MANAGE,

    searchFields: [
      "approval_type",
      "approval_status",
      "remarks"
    ],

    filterFields: [
      "student_registration_id",
      "approval_type",
      "approval_status"
    ],

    defaultOrderField: "created_at",

    fields: {
      studentRegistrationId: "student_registration_id",
      approvalType: "approval_type",
      approvalStatus: "approval_status",
      approvedBy: "approved_by",
      approvedAt: "approved_at",
      remarks: "remarks"
    }
  },
  "/approvals"
);

export default router;
