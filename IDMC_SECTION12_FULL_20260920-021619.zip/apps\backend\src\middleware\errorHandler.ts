﻿import { NextFunction, Request, Response } from "express";

type HttpError = Error & {
  statusCode?: number;
  status?: number;
};

export function errorHandler(
  err: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction
) {
  console.error(err);

  const message =
    err instanceof Error ? err.message : "Internal server error";

  const httpError =
    err instanceof Error ? (err as HttpError) : undefined;

  const candidateStatus =
    httpError?.statusCode ?? httpError?.status;

  const statusCode =
    typeof candidateStatus === "number" &&
    Number.isInteger(candidateStatus) &&
    candidateStatus >= 400 &&
    candidateStatus <= 599
      ? candidateStatus
      : 500;

  return res.status(statusCode).json({
    success: false,
    message,
  });
}
