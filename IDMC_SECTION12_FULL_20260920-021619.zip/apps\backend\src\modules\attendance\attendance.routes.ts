﻿import { Router } from "express";
import { authenticate } from "../../middleware/auth.js";
import { registerCrudResource } from "../../utils/resourceCrud.js";

const router = Router();

router.use(authenticate);

const VIEW = "attendance.view";
const MANAGE = "attendance.manage";

registerCrudResource(
  router,
  {
    moduleCode: "ATTENDANCE",
    entityType: "attendance_sessions",
    table: "attendance_sessions",
    permissionView: VIEW,
    permissionManage: MANAGE,

    searchFields: [
      "session_type",
      "topic",
      "status",
      "notes"
    ],

    filterFields: [
      "class_id",
      "course_offering_id",
      "timetable_entry_id",
      "session_date",
      "session_type",
      "venue_room_id",
      "conducted_by",
      "status"
    ],

    defaultOrderField: "session_date",

    fields: {
      classId: "class_id",
      courseOfferingId: "course_offering_id",
      timetableEntryId: "timetable_entry_id",
      sessionDate: "session_date",
      startTime: "start_time",
      endTime: "end_time",
      sessionType: "session_type",
      topic: "topic",
      venueRoomId: "venue_room_id",
      conductedBy: "conducted_by",
      status: "status",
      openedAt: "opened_at",
      submittedAt: "submitted_at",
      lockedAt: "locked_at",
      lockedBy: "locked_by",
      notes: "notes",
      createdBy: "created_by",
      updatedBy: "updated_by"
    }
  },
  "/"
);

registerCrudResource(
  router,
  {
    moduleCode: "ATTENDANCE",
    entityType: "attendance_records",
    table: "attendance_records",
    permissionView: VIEW,
    permissionManage: MANAGE,

    searchFields: [
      "attendance_status",
      "remarks"
    ],

    filterFields: [
      "attendance_session_id",
      "student_id",
      "course_registration_id",
      "attendance_status",
      "correction_required"
    ],

    defaultOrderField: "created_at",

    fields: {
      attendanceSessionId: "attendance_session_id",
      studentId: "student_id",
      courseRegistrationId: "course_registration_id",
      attendanceStatus: "attendance_status",
      checkInTime: "check_in_time",
      minutesLate: "minutes_late",
      remarks: "remarks",
      markedBy: "marked_by",
      markedAt: "marked_at",
      correctionRequired: "correction_required"
    }
  },
  "/records"
);

registerCrudResource(
  router,
  {
    moduleCode: "ATTENDANCE",
    entityType: "attendance_corrections",
    table: "attendance_corrections",
    permissionView: VIEW,
    permissionManage: MANAGE,

    searchFields: [
      "old_status",
      "new_status",
      "reason",
      "status",
      "review_comment"
    ],

    filterFields: [
      "attendance_record_id",
      "requested_by",
      "status",
      "reviewed_by"
    ],

    defaultOrderField: "requested_at",

    fields: {
      attendanceRecordId: "attendance_record_id",
      requestedBy: "requested_by",
      requestedAt: "requested_at",
      oldStatus: "old_status",
      newStatus: "new_status",
      oldCheckInTime: "old_check_in_time",
      newCheckInTime: "new_check_in_time",
      reason: "reason",
      evidenceFileId: "evidence_file_id",
      status: "status",
      reviewedBy: "reviewed_by",
      reviewedAt: "reviewed_at",
      reviewComment: "review_comment"
    }
  },
  "/corrections"
);

export default router;
