import { Router } from "express";
import * as controller from "../controllers/finance.controller.js";
import { authenticate } from "../../../middleware/auth.js";
import { requirePermission } from "../../../middleware/rbac.js";
import { registerCrudResource } from "../../../utils/resourceCrud.js";

const router = Router();
router.use(authenticate);

registerCrudResource(
  router,
  {
    moduleCode: "FINANCE",
    entityType: "fee_structures",
    table: "fee_structures",
    permissionView: "finance.view",
    permissionManage: "finance.manage",
    searchFields: [
      "fee_structure_code",
      "fee_structure_name",
      "academic_year",
      "semester",
      "status",
      "currency_code"
    ],
    filterFields: [
      "academic_year",
      "semester",
      "status",
      "currency_code"
    ],
    defaultOrderField: "created_at",
    fields: {
      feeStructureCode: "fee_structure_code",
      feeStructureName: "fee_structure_name",
      academicYear: "academic_year",
      semester: "semester",
      description: "description",
      status: "status",
      currencyCode: "currency_code",
      effectiveFrom: "effective_from",
      effectiveTo: "effective_to",
      createdBy: "created_by",
      updatedBy: "updated_by"
    }
  },
  "/fee-structures"
);

router.get("/students/:studentId/account", requirePermission("finance.view"), controller.getFinancialAccount);
router.get("/students/:studentId/charges", requirePermission("finance.charges.view"), controller.getCharges);
router.get("/students/:studentId/invoices", requirePermission("finance.invoices.view"), controller.getInvoices);
router.get("/students/:studentId/payments", requirePermission("finance.payments.view"), controller.getPayments);
router.get("/students/:studentId/refunds", requirePermission("finance.refunds.view"), controller.getRefunds);
router.get("/students/:studentId/scholarships", requirePermission("finance.scholarships.view"), controller.getScholarships);
router.get("/students/:studentId/adjustments", requirePermission("finance.charges.view"), controller.getAdjustments);
router.get("/students/:studentId/transactions", requirePermission("finance.view"), controller.getTransactions);

export default router;
