﻿import { Router } from 'express';
import * as controller from '../controllers/finance.controller.js';

const router = Router();

/*
 * Fee structures
 */
router.get('/fee-structures', controller.listFeeStructures);
router.get('/fee-structures/:id', controller.getFeeStructure);

/*
 * Student finance
 */
router.get(
  '/students/:studentId/account',
  controller.getFinancialAccount
);

router.get(
  '/students/:studentId/charges',
  controller.getCharges
);

router.get(
  '/students/:studentId/invoices',
  controller.getInvoices
);

router.get(
  '/students/:studentId/payments',
  controller.getPayments
);

router.get(
  '/students/:studentId/refunds',
  controller.getRefunds
);

router.get(
  '/students/:studentId/scholarships',
  controller.getScholarships
);

router.get(
  '/students/:studentId/adjustments',
  controller.getAdjustments
);

router.get(
  '/students/:studentId/transactions',
  controller.getTransactions
);

export default router;
