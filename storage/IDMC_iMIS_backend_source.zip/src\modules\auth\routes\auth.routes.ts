﻿import { Router } from "express";
import * as controller from "../controllers/auth.controller.js";
import { authenticate } from "../../../middleware/auth.js";

const router = Router();

router.get("/health", controller.authHealth);

router.get("/me", authenticate, controller.me);

export default router;
