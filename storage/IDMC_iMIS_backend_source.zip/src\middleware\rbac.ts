﻿import type { NextFunction, Request, Response } from "express";
import { getSupabase } from "../config/database.js";

export function requirePermission(permissionCode: string) {
  return async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      if (!req.user) {
        res.status(401).json({
          success: false,
          message: "Authentication required"
        });
        return;
      }

      const supabase = getSupabase();

      const { data, error } = await supabase
        .from("user_roles")
        .select(`
          id,
          status,
          expires_at,
          roles!inner (
            id,
            role_code,
            status,
            role_permissions!inner (
              permissions!inner (
                permission_code,
                status
              )
            )
          )
        `)
        .eq("user_id", req.user.id)
        .eq("status", "ACTIVE");

      if (error) {
        next(error);
        return;
      }

      const now = new Date();

      const hasPermission = (data ?? []).some((userRole: any) => {
        if (
          userRole.status !== "ACTIVE" ||
          userRole.roles?.status !== "ACTIVE"
        ) {
          return false;
        }

        if (
          userRole.expires_at &&
          new Date(userRole.expires_at) <= now
        ) {
          return false;
        }

        const rolePermissions =
          userRole.roles?.role_permissions ?? [];

        return rolePermissions.some(
          (rolePermission: any) =>
            rolePermission.permissions?.status === "ACTIVE" &&
            rolePermission.permissions?.permission_code === permissionCode
        );
      });

      if (!hasPermission) {
        res.status(403).json({
          success: false,
          message: `Permission denied: ${permissionCode}`
        });
        return;
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}

export function requireRole(...roleCodes: string[]) {
  return async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      if (!req.user) {
        res.status(401).json({
          success: false,
          message: "Authentication required"
        });
        return;
      }

      const supabase = getSupabase();

      const { data, error } = await supabase
        .from("user_roles")
        .select(`
          status,
          expires_at,
          roles!inner (
            role_code,
            status
          )
        `)
        .eq("user_id", req.user.id)
        .eq("status", "ACTIVE");

      if (error) {
        next(error);
        return;
      }

      const now = new Date();

      const hasRole = (data ?? []).some((userRole: any) => {
        if (
          userRole.status !== "ACTIVE" ||
          userRole.roles?.status !== "ACTIVE"
        ) {
          return false;
        }

        if (
          userRole.expires_at &&
          new Date(userRole.expires_at) <= now
        ) {
          return false;
        }

        return roleCodes.includes(userRole.roles.role_code);
      });

      if (!hasRole) {
        res.status(403).json({
          success: false,
          message: "Required role not assigned"
        });
        return;
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}
