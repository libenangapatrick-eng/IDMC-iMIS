﻿export const APP_NAME = "IDMC Integrated Management Information System";

export const API_PREFIX = "/api";

export const API_VERSION = "v1";

export const API_BASE = `${API_PREFIX}/${API_VERSION}`;
