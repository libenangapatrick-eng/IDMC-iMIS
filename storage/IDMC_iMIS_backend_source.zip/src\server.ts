﻿import app from "./app.js";
import { env } from "./config/env.js";
import { logInfo } from "./utils/logger.js";

const server = app.listen(env.PORT, () => {
  logInfo(
    `IDMC iMIS API running on http://localhost:${env.PORT}`
  );

  logInfo(
    `Health check: http://localhost:${env.PORT}/api/v1/health`
  );
});

function shutdown(signal: string) {
  logInfo(`${signal} received. Shutting down server...`);

  server.close(() => {
    logInfo("HTTP server closed.");
    process.exit(0);
  });
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
